---
name: This Week in Ethereum Template
category: 
---

###Current Status 

### Protocol

## Clients

### AlethZero

### Mist

###pyethereum

##Projects

##People 

##In the Media

##Upcoming Events

### Meetups
