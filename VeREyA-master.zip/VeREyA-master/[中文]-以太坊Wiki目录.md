中文读者可以在[以太坊爱好者社区](http://ethfans.org)获知最新信息。

白皮书：[以太坊（Ethereum ）:下一代智能合约和去中心化应用平台](https://github.com/ethereum/wiki/blob/master/%5B%E4%B8%AD%E6%96%87%5D-%E4%BB%A5%E5%A4%AA%E5%9D%8A%E7%99%BD%E7%9A%AE%E4%B9%A6.md)

[Serpent语言指南](https://github.com/ethereum/wiki/blob/master/%5B%E4%B8%AD%E6%96%87%5D-Serpent%E6%8C%87%E5%8D%97.md)

[以太坊开发计划](https://github.com/ethereum/wiki/blob/master/%5B%E4%B8%AD%E6%96%87%5D-%E4%BB%A5%E5%A4%AA%E5%9D%8A%E5%BC%80%E5%8F%91%E8%AE%A1%E5%88%92.md)

[术语表](https://github.com/ethereum/wiki/blob/master/%5B%E4%B8%AD%E6%96%87%5D-%E4%BB%A5%E5%A4%AA%E5%9D%8A%E6%9C%AF%E8%AF%AD%E8%A1%A8.md)

[网络状态监控](https://github.com/ethereum/wiki/blob/master/%5B%E4%B8%AD%E6%96%87%5D-%E7%BD%91%E7%BB%9C%E7%8A%B6%E6%80%81.md)
