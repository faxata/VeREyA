https://gitter.im/ethereum

# Node Software ("Clients")

## Go

https://gitter.im/ethereum/go-ethereum

## CPP 

https://gitter.im/ethereum/cpp-ethereum

## Python 

https://gitter.im/ethereum/pyethapp - the client

https://gitter.im/ethereum/pyethereum - the core library (evm, blocks, txs, ...)

https://gitter.im/ethereum/pydevp2p - p2p network  

# DApp Development

https://gitter.im/ethereum/web3.js

https://gitter.im/ethereum/mist

https://gitter.im/ethereum/solidity

https://gitter.im/ethereum/serpent

# Other

https://gitter.im/ethereum/porting

https://gitter.im/ethereum/research

# Protocol

https://gitter.im/ethereum/devp2p

https://gitter.im/ethereum/light-client



