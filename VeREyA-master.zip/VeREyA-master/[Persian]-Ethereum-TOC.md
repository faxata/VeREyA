---
name: Ethereum TOC
category: 
---

### به اتریوم، نسل بعدی قراردادهای هوشمند و نرم افزارهای غیر متمرکز خوش آمدید

[برگ سفید](https://github.com/ethereum/wiki/wiki/%5BPersian%5D-White-Paper)