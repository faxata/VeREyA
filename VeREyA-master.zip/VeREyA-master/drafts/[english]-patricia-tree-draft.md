---
name: Patricia Tree
category: 
---

The best known tutorial/explanation of the ethereum patricia tree is here:
https://easythereentropy.wordpress.com/2014/06/04/understanding-the-ethereum-trie/