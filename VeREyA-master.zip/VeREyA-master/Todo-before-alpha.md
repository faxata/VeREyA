---
name: TODO Before Alpha
category: 
---

## Etereum P2P sub-protocol

* Fix numbering in [Wire](https://github.com/ethereum/wiki/wiki/Ethereum-Wire-Protocol) protocol. 
* Add `gasprice` message
    * `[[id, price], [id, price], ...]`