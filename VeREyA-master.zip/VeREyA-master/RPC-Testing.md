---
name: RPC Testing
category: 
---

```
{
  blockchain: [
    {
      difficulty: 1024,
      transactions: [
        ...
      ]
    }, 
  ]
}
```