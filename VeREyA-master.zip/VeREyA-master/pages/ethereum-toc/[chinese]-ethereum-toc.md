---
name: Ethereum TOC
category: 
---

中文读者可以在以太坊中文社区( www.1tf.org )获知最新信息。

白皮书：[以太坊（Ethereum ）:下一代智能合约和去中心化应用平台](https://github.com/ethereum/wiki/wiki/White-Paper-%5BChinese%5D)

[Serpent语言指南](https://github.com/ethereum/wiki/wiki/%5B%E4%B8%AD%E6%96%87%5D-Serpent%E6%8C%87%E5%8D%97)

[以太坊开发计划](https://github.com/ethereum/wiki/wiki/%E4%BB%A5%E5%A4%AA%E5%9D%8A%E5%BC%80%E5%8F%91%E8%AE%A1%E5%88%92)

[术语表](https://github.com/ethereum/wiki/wiki/%E6%9C%AF%E8%AF%AD%E8%A1%A8)

[网络状态监控](https://github.com/ethereum/wiki/wiki/Network-Status-%28Chinese%29)